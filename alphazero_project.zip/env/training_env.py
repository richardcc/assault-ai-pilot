from core.planner.plan_context import PlanContext
from core.decision.decision import decide
from core.telemetry.logger import log

class TrainingEnv:

    def __init__(self, game):
        self.game = game
        self.state = None

    def reset(self, state):
        self.state = state

    def step(self):
        plan = PlanContext()
        action, out = decide(self.state, plan)
        self.state = self.game.step(self.state, action)

        log({
            "policy": out["policy"],
            "value": out["value"],
            "action": action
        })

        return self.state
