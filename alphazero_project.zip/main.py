from env.training_env import TrainingEnv

# Dummy simulation placeholder
class DummySim:
    def get_legal_actions(self, state):
        return [0,1,2,3,4]
    def step(self, state, action):
        return state
    def is_done(self, state):
        return False

from integration.assault_model_adapter import AssaultModelAdapter

sim = DummySim()
game = AssaultModelAdapter(sim)

env = TrainingEnv(game)
state = {}
env.reset(state)

for _ in range(3):
    env.step()
