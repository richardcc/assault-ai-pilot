from core.interfaces import GameInterface

class AssaultModelAdapter(GameInterface):
    def __init__(self, sim):
        self.sim = sim

    def get_legal_actions(self, state):
        return self.sim.get_legal_actions(state)

    def step(self, state, action):
        return self.sim.step(state, action)

    def is_terminal(self, state):
        return self.sim.is_done(state)
