import random

def forward(x):
    # dummy policy
    policy = [random.random() for _ in range(5)]
    total = sum(policy)
    policy = [p/total for p in policy]
    value = 0.0
    return {"policy": policy, "value": value}
