def encode(state, plan):
    # TODO: implement real encoding
    return state
