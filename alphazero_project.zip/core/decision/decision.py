from core.encoder.encoder import encode
from core.model.model import forward


def decide(state, plan):
    x = encode(state, plan)
    out = forward(x)
    action = out["policy"].index(max(out["policy"]))
    return action, out
