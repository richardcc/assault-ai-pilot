# Ruleset interface / specification

